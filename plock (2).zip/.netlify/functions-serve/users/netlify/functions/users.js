var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/users.mjs
var users_exports = {};
__export(users_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(users_exports);

// netlify/functions/_util.mjs
async function getStore() {
  if (process.env.LOCAL_BLOBS === "1" || process.env.NETLIFY_DEV === "true") {
    const fs = await import("fs");
    const path = (n) => `.data/${n}`;
    return {
      async get(key, { type } = {}) {
        try {
          const raw = fs.readFileSync(path(key), "utf8");
          return type === "json" ? JSON.parse(raw) : raw;
        } catch {
          return null;
        }
      },
      async setJSON(key, data) {
        fs.mkdirSync(".data", { recursive: true });
        fs.writeFileSync(path(key), JSON.stringify(data));
        return true;
      }
    };
  } else {
    const { getStore: getStore2 } = await import("@netlify/blobs");
    return getStore2("inlev");
  }
}
function json(status, body, cookie) {
  const h = { "content-type": "application/json", "access-control-allow-origin": "*", "access-control-allow-credentials": "true" };
  if (cookie)
    h["set-cookie"] = cookie;
  return { statusCode: status, headers: h, body: JSON.stringify(body) };
}
function parseCookies(evt) {
  const s = evt.headers && evt.headers.cookie || "";
  const out = {};
  s.split(";").forEach((p) => {
    const i = p.indexOf("=");
    if (i > 0) {
      out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
    }
  });
  return out;
}

// netlify/functions/users.mjs
var USERS_KEY = "users.json";
var SESS_KEY = "sessions.json";
async function currentUser(store, cookies) {
  const S = await store.get(SESS_KEY, { type: "json" }) || {};
  const token = cookies["inlev_sess"];
  const u = token && S[token];
  return u || null;
}
async function handler(event) {
  const store = await getStore();
  const path = (event.path || "").replace(/^\/.netlify\/functions\/[\w-]+/, "");
  const method = event.httpMethod || "GET";
  const cookies = parseCookies(event);
  const me = await currentUser(store, cookies);
  if (me !== "Admin")
    return json(403, { error: "admin only" });
  if (path.endsWith("/list")) {
    const db = await store.get(USERS_KEY, { type: "json" }) || { users: {} };
    return json(200, { users: Object.keys(db.users) });
  }
  if (path.endsWith("/add") && method === "POST") {
    const b = JSON.parse(event.body || "{}");
    const db = await store.get(USERS_KEY, { type: "json" }) || { users: {} };
    if (!b.username || !b.password)
      return json(400, { error: "missing" });
    if (db.users[b.username])
      return json(400, { error: "exists" });
    db.users[b.username] = { hash: String(b.password) };
    await store.setJSON(USERS_KEY, db);
    return json(200, { ok: true });
  }
  if (path.endsWith("/delete") && method === "POST") {
    const b = JSON.parse(event.body || "{}");
    const db = await store.get(USERS_KEY, { type: "json" }) || { users: {} };
    if (b.username === "Admin")
      return json(400, { error: "cannot delete Admin" });
    delete db.users[b.username];
    await store.setJSON(USERS_KEY, db);
    return json(200, { ok: true });
  }
  return json(404, { error: "not found", path, method });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=users.js.map
