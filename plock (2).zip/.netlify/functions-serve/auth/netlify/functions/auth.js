// netlify/functions/auth.js
var json = (statusCode, body = {}, extraHeaders = {}) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    ...extraHeaders
  },
  body: JSON.stringify(body)
});
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
      },
      body: ""
    };
  }
  const path = (event.path || "").replace(/^\/\.netlify\/functions\/auth/, "");
  const method = event.httpMethod || "GET";
  if (method === "GET" && path === "/health") {
    return json(200, { ok: true, service: "auth", ts: (/* @__PURE__ */ new Date()).toISOString() });
  }
  if (method === "POST" && path === "/login") {
    try {
      const { username, password } = JSON.parse(event.body || "{}");
      const USER = process.env.ADMIN_USER || "Admin";
      const PASS = process.env.ADMIN_PASS || "1234";
      if (username === USER && password === PASS) {
        const token = Buffer.from(`${USER}:${Date.now()}`).toString("base64");
        return json(200, { token });
      }
      return json(401, { error: "Fel anv\xE4ndarnamn eller l\xF6senord" });
    } catch (err) {
      return json(400, { error: "Ogiltig beg\xE4ran", details: String(err && err.message || err) });
    }
  }
  return json(404, { error: "Not found", method, path });
};
//# sourceMappingURL=auth.js.map
