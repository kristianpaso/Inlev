var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/schema.mjs
var schema_exports = {};
__export(schema_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(schema_exports);

// netlify/functions/_util.mjs
async function getStore() {
  if (process.env.LOCAL_BLOBS === "1" || process.env.NETLIFY_DEV === "true") {
    const fs = await import("fs");
    const path = (n) => `.data/${n}`;
    return {
      async get(key, { type } = {}) {
        try {
          const raw = fs.readFileSync(path(key), "utf8");
          return type === "json" ? JSON.parse(raw) : raw;
        } catch {
          return null;
        }
      },
      async setJSON(key, data) {
        fs.mkdirSync(".data", { recursive: true });
        fs.writeFileSync(path(key), JSON.stringify(data));
        return true;
      }
    };
  } else {
    const { getStore: getStore2 } = await import("@netlify/blobs");
    return getStore2("inlev");
  }
}
function json(status, body, cookie) {
  const h = { "content-type": "application/json", "access-control-allow-origin": "*", "access-control-allow-credentials": "true" };
  if (cookie)
    h["set-cookie"] = cookie;
  return { statusCode: status, headers: h, body: JSON.stringify(body) };
}

// netlify/functions/schema.mjs
var CONF = "schema_config.json";
var ENTRIES = "schema_entries.json";
async function handler(event) {
  const store = await getStore();
  const path = (event.path || "").replace(/^\/.netlify\/functions\/[\w-]+/, "");
  const method = event.httpMethod || "GET";
  if (path.endsWith("/config")) {
    if (method === "GET") {
      const d = await store.get(CONF, { type: "json" }) || { areas: [], people: [] };
      return json(200, d);
    }
    if (method === "POST") {
      const b = JSON.parse(event.body || "{}");
      await store.setJSON(CONF, b);
      return json(200, { ok: true });
    }
  }
  if (path.endsWith("/entries")) {
    if (method === "GET") {
      const d = await store.get(ENTRIES, { type: "json" }) || { items: [] };
      return json(200, d);
    }
    if (method === "POST") {
      const d = await store.get(ENTRIES, { type: "json" }) || { items: [] };
      const b = JSON.parse(event.body || "{}");
      const id = "e_" + Date.now();
      d.items.push({ id, ...b });
      await store.setJSON(ENTRIES, d);
      return json(200, { ok: true, id });
    }
  }
  if (path.endsWith("/stats")) {
    const d = await store.get(ENTRIES, { type: "json" }) || { items: [] };
    const totals = {}, perAreas = {};
    (d.items || []).forEach((e) => (e.assignments || []).forEach((a) => {
      totals[a.person] = (totals[a.person] || 0) + 1;
      (perAreas[a.person] = perAreas[a.person] || {})[a.area] = (perAreas[a.person][a.area] || 0) + 1;
    }));
    return json(200, { totals, perAreas });
  }
  return json(404, { error: "not found", path, method });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=schema.js.map
