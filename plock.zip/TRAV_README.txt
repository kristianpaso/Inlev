Detta lades till:
- /trav/trav.html
- /trav/assets/trav.css
- /trav/assets/trav.js
- /trav.html (redirect till /trav/trav.html)

Länka i meny (ex. inloggade nav):
<a href="/trav/trav.html">Trav</a>
