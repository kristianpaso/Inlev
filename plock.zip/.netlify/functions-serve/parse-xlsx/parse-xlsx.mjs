
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/parse-xlsx.mjs
import { Buffer } from "node:buffer";
import * as XLSX from "xlsx";
function json(status, data) {
  return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json" } });
}
var parse_xlsx_default = async (req) => {
  try {
    if (req.method !== "POST")
      return json(405, { error: "Use POST with binary body" });
    const ab = await req.arrayBuffer();
    const buf = Buffer.from(ab);
    const wb = XLSX.read(buf, { type: "buffer", cellDates: true });
    const names = wb.SheetNames || [];
    if (!names.length)
      return json(400, { error: "No sheets found" });
    const first = names[0];
    const ws = wb.Sheets[first];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: null, raw: true, cellDates: true });
    return json(200, { ok: true, sheet: first, sheets: names, rows });
  } catch (e) {
    return json(500, { error: String(e && e.message || e) });
  }
};
export {
  parse_xlsx_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibmV0bGlmeS9mdW5jdGlvbnMvcGFyc2UteGxzeC5tanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IGJ1ZmZlciB9IGZyb20gJ25vZGU6c3RyZWFtL2NvbnN1bWVycyc7XG5pbXBvcnQgeyBCdWZmZXIgfSBmcm9tICdub2RlOmJ1ZmZlcic7XG5pbXBvcnQgKiBhcyBYTFNYIGZyb20gJ3hsc3gnO1xuXG5mdW5jdGlvbiBqc29uKHN0YXR1cywgZGF0YSl7IFxuICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KGRhdGEpLCB7IHN0YXR1cywgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzonYXBwbGljYXRpb24vanNvbicgfSB9KTsgXG59XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIChyZXEpID0+IHtcbiAgdHJ5e1xuICAgIGlmKHJlcS5tZXRob2QgIT09ICdQT1NUJykgcmV0dXJuIGpzb24oNDA1LCB7IGVycm9yOiAnVXNlIFBPU1Qgd2l0aCBiaW5hcnkgYm9keScgfSk7XG4gICAgY29uc3QgYWIgPSBhd2FpdCByZXEuYXJyYXlCdWZmZXIoKTtcbiAgICBjb25zdCBidWYgPSBCdWZmZXIuZnJvbShhYik7XG4gICAgY29uc3Qgd2IgPSBYTFNYLnJlYWQoYnVmLCB7IHR5cGU6ICdidWZmZXInLCBjZWxsRGF0ZXM6IHRydWUgfSk7XG4gICAgY29uc3QgbmFtZXMgPSB3Yi5TaGVldE5hbWVzIHx8IFtdO1xuICAgIGlmKCFuYW1lcy5sZW5ndGgpIHJldHVybiBqc29uKDQwMCwgeyBlcnJvcjogJ05vIHNoZWV0cyBmb3VuZCcgfSk7XG4gICAgY29uc3QgZmlyc3QgPSBuYW1lc1swXTtcbiAgICBjb25zdCB3cyA9IHdiLlNoZWV0c1tmaXJzdF07XG4gICAgY29uc3Qgcm93cyA9IFhMU1gudXRpbHMuc2hlZXRfdG9fanNvbih3cywgeyBkZWZ2YWw6IG51bGwsIHJhdzogdHJ1ZSwgY2VsbERhdGVzOiB0cnVlIH0pO1xuICAgIHJldHVybiBqc29uKDIwMCwgeyBvazp0cnVlLCBzaGVldDpmaXJzdCwgc2hlZXRzOm5hbWVzLCByb3dzIH0pO1xuICB9Y2F0Y2goZSl7XG4gICAgcmV0dXJuIGpzb24oNTAwLCB7IGVycm9yOiBTdHJpbmcoZSAmJiBlLm1lc3NhZ2UgfHwgZSkgfSk7XG4gIH1cbn0iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7O0FBQ0EsU0FBUyxjQUFjO0FBQ3ZCLFlBQVksVUFBVTtBQUV0QixTQUFTLEtBQUssUUFBUSxNQUFLO0FBQ3pCLFNBQU8sSUFBSSxTQUFTLEtBQUssVUFBVSxJQUFJLEdBQUcsRUFBRSxRQUFRLFNBQVMsRUFBRSxnQkFBZSxtQkFBbUIsRUFBRSxDQUFDO0FBQ3RHO0FBRUEsSUFBTyxxQkFBUSxPQUFPLFFBQVE7QUFDNUIsTUFBRztBQUNELFFBQUcsSUFBSSxXQUFXO0FBQVEsYUFBTyxLQUFLLEtBQUssRUFBRSxPQUFPLDRCQUE0QixDQUFDO0FBQ2pGLFVBQU0sS0FBSyxNQUFNLElBQUksWUFBWTtBQUNqQyxVQUFNLE1BQU0sT0FBTyxLQUFLLEVBQUU7QUFDMUIsVUFBTSxLQUFVLFVBQUssS0FBSyxFQUFFLE1BQU0sVUFBVSxXQUFXLEtBQUssQ0FBQztBQUM3RCxVQUFNLFFBQVEsR0FBRyxjQUFjLENBQUM7QUFDaEMsUUFBRyxDQUFDLE1BQU07QUFBUSxhQUFPLEtBQUssS0FBSyxFQUFFLE9BQU8sa0JBQWtCLENBQUM7QUFDL0QsVUFBTSxRQUFRLE1BQU0sQ0FBQztBQUNyQixVQUFNLEtBQUssR0FBRyxPQUFPLEtBQUs7QUFDMUIsVUFBTSxPQUFZLFdBQU0sY0FBYyxJQUFJLEVBQUUsUUFBUSxNQUFNLEtBQUssTUFBTSxXQUFXLEtBQUssQ0FBQztBQUN0RixXQUFPLEtBQUssS0FBSyxFQUFFLElBQUcsTUFBTSxPQUFNLE9BQU8sUUFBTyxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQy9ELFNBQU8sR0FBRTtBQUNQLFdBQU8sS0FBSyxLQUFLLEVBQUUsT0FBTyxPQUFPLEtBQUssRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDO0FBQUEsRUFDekQ7QUFDRjsiLAogICJuYW1lcyI6IFtdCn0K
