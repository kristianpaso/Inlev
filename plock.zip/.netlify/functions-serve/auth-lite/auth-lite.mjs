
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth-lite.mjs
import jwt from "jsonwebtoken";
var SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function json(status, obj) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json" } });
}
function parse(path) {
  return path.replace(/^\/api\//, "");
}
function tokenFor(u) {
  const exp = Math.floor(Date.now() / 1e3) + 3600;
  const t = jwt.sign({ sub: u.username, role: u.role, exp }, SECRET);
  return { token: t, exp };
}
function getUserFromAuth(auth) {
  const raw = auth?.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!raw)
    return null;
  try {
    const payload = jwt.verify(raw, SECRET);
    return { username: payload.sub, role: payload.role };
  } catch (_) {
    return null;
  }
}
var auth_lite_default = async (req) => {
  const url = new URL(req.url);
  const path = parse(url.pathname.replace(/^.*\/.netlify\/(functions|lambda)\//, ""));
  if (req.method === "GET" && (path === "auth-lite/health" || path === "health")) {
    return json(200, { ok: true });
  }
  if (req.method === "POST" && (path === "auth-lite/login" || path === "login")) {
    const body = await req.json().catch(() => null);
    if (!body)
      return json(400, { error: "bad json" });
    const { username, password } = body;
    if (username === "Admin" && password === "admin") {
      const { token, exp } = tokenFor({ username: "Admin", role: "admin" });
      return json(200, { token, exp, user: { name: "Admin", role: "admin" } });
    }
    return json(401, { error: "invalid" });
  }
  if (req.method === "GET" && (path === "auth-lite/me" || path === "me")) {
    const me = getUserFromAuth(req.headers.get("authorization") || "");
    if (!me)
      return json(401, { error: "unauthorized" });
    return json(200, { user: { name: me.username, role: me.role } });
  }
  return json(404, { error: "not found", path });
};
export {
  auth_lite_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibmV0bGlmeS9mdW5jdGlvbnMvYXV0aC1saXRlLm1qcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IGp3dCBmcm9tICdqc29ud2VidG9rZW4nO1xuXG5jb25zdCBTRUNSRVQgPSBwcm9jZXNzLmVudi5KV1RfU0VDUkVUIHx8ICdkZXYtc2VjcmV0LWNoYW5nZS1tZSc7XG5mdW5jdGlvbiBqc29uKHN0YXR1cyxvYmopeyByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KG9iaikse3N0YXR1cyxoZWFkZXJzOnsnQ29udGVudC1UeXBlJzonYXBwbGljYXRpb24vanNvbid9fSk7IH1cbmZ1bmN0aW9uIHBhcnNlKHBhdGgpeyByZXR1cm4gcGF0aC5yZXBsYWNlKC9eXFwvYXBpXFwvLywnJyk7IH1cbmZ1bmN0aW9uIHRva2VuRm9yKHUpeyBjb25zdCBleHA9TWF0aC5mbG9vcihEYXRlLm5vdygpLzEwMDApKzM2MDA7IGNvbnN0IHQ9and0LnNpZ24oe3N1Yjp1LnVzZXJuYW1lLHJvbGU6dS5yb2xlLGV4cH0sIFNFQ1JFVCk7IHJldHVybiB7dG9rZW46dCxleHB9OyB9XG5mdW5jdGlvbiBnZXRVc2VyRnJvbUF1dGgoYXV0aCl7XG4gIGNvbnN0IHJhdyA9IGF1dGg/LnN0YXJ0c1dpdGgoJ0JlYXJlciAnKSA/IGF1dGguc2xpY2UoNykgOiBudWxsO1xuICBpZighcmF3KSByZXR1cm4gbnVsbDtcbiAgdHJ5eyBjb25zdCBwYXlsb2FkID0gand0LnZlcmlmeShyYXcsIFNFQ1JFVCk7IHJldHVybiB7IHVzZXJuYW1lOiBwYXlsb2FkLnN1Yiwgcm9sZTogcGF5bG9hZC5yb2xlIH07IH1cbiAgY2F0Y2goXyl7IHJldHVybiBudWxsOyB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIChyZXEpID0+IHtcbiAgY29uc3QgdXJsID0gbmV3IFVSTChyZXEudXJsKTtcbiAgY29uc3QgcGF0aCA9IHBhcnNlKHVybC5wYXRobmFtZS5yZXBsYWNlKC9eLipcXC8ubmV0bGlmeVxcLyhmdW5jdGlvbnN8bGFtYmRhKVxcLy8sJycpKTtcblxuICAvLyBIZWFsdGg6IG5ldmVyIGZhaWxzLCBubyBleHRlcm5hbCBkZXBzXG4gIGlmKHJlcS5tZXRob2Q9PT0nR0VUJyAmJiAocGF0aD09PSdhdXRoLWxpdGUvaGVhbHRoJyB8fCBwYXRoPT09J2hlYWx0aCcpKXtcbiAgICByZXR1cm4ganNvbigyMDAse29rOnRydWV9KTtcbiAgfVxuXG4gIGlmKHJlcS5tZXRob2Q9PT0nUE9TVCcgJiYgKHBhdGg9PT0nYXV0aC1saXRlL2xvZ2luJyB8fCBwYXRoPT09J2xvZ2luJykpe1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXEuanNvbigpLmNhdGNoKCgpPT5udWxsKTtcbiAgICBpZighYm9keSkgcmV0dXJuIGpzb24oNDAwLHtlcnJvcjonYmFkIGpzb24nfSk7XG4gICAgY29uc3Qge3VzZXJuYW1lLHBhc3N3b3JkfSA9IGJvZHk7XG4gICAgaWYodXNlcm5hbWU9PT0nQWRtaW4nICYmIHBhc3N3b3JkPT09J2FkbWluJyl7XG4gICAgICBjb25zdCB7dG9rZW4sZXhwfSA9IHRva2VuRm9yKHsgdXNlcm5hbWU6J0FkbWluJywgcm9sZTonYWRtaW4nIH0pO1xuICAgICAgcmV0dXJuIGpzb24oMjAwLHt0b2tlbixleHAsdXNlcjp7bmFtZTonQWRtaW4nLHJvbGU6J2FkbWluJ319KTtcbiAgICB9XG4gICAgcmV0dXJuIGpzb24oNDAxLHtlcnJvcjonaW52YWxpZCd9KTtcbiAgfVxuXG4gIGlmKHJlcS5tZXRob2Q9PT0nR0VUJyAmJiAocGF0aD09PSdhdXRoLWxpdGUvbWUnIHx8IHBhdGg9PT0nbWUnKSl7XG4gICAgY29uc3QgbWUgPSBnZXRVc2VyRnJvbUF1dGgocmVxLmhlYWRlcnMuZ2V0KCdhdXRob3JpemF0aW9uJyl8fCcnKTtcbiAgICBpZighbWUpIHJldHVybiBqc29uKDQwMSx7ZXJyb3I6J3VuYXV0aG9yaXplZCd9KTtcbiAgICByZXR1cm4ganNvbigyMDAse3VzZXI6e25hbWU6bWUudXNlcm5hbWUsIHJvbGU6bWUucm9sZX19KTtcbiAgfVxuXG4gIHJldHVybiBqc29uKDQwNCx7ZXJyb3I6J25vdCBmb3VuZCcsIHBhdGh9KTtcbn07Il0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7OztBQUFBLE9BQU8sU0FBUztBQUVoQixJQUFNLFNBQVMsUUFBUSxJQUFJLGNBQWM7QUFDekMsU0FBUyxLQUFLLFFBQU8sS0FBSTtBQUFFLFNBQU8sSUFBSSxTQUFTLEtBQUssVUFBVSxHQUFHLEdBQUUsRUFBQyxRQUFPLFNBQVEsRUFBQyxnQkFBZSxtQkFBa0IsRUFBQyxDQUFDO0FBQUc7QUFDMUgsU0FBUyxNQUFNLE1BQUs7QUFBRSxTQUFPLEtBQUssUUFBUSxZQUFXLEVBQUU7QUFBRztBQUMxRCxTQUFTLFNBQVMsR0FBRTtBQUFFLFFBQU0sTUFBSSxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUUsR0FBSSxJQUFFO0FBQU0sUUFBTSxJQUFFLElBQUksS0FBSyxFQUFDLEtBQUksRUFBRSxVQUFTLE1BQUssRUFBRSxNQUFLLElBQUcsR0FBRyxNQUFNO0FBQUcsU0FBTyxFQUFDLE9BQU0sR0FBRSxJQUFHO0FBQUc7QUFDcEosU0FBUyxnQkFBZ0IsTUFBSztBQUM1QixRQUFNLE1BQU0sTUFBTSxXQUFXLFNBQVMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJO0FBQzFELE1BQUcsQ0FBQztBQUFLLFdBQU87QUFDaEIsTUFBRztBQUFFLFVBQU0sVUFBVSxJQUFJLE9BQU8sS0FBSyxNQUFNO0FBQUcsV0FBTyxFQUFFLFVBQVUsUUFBUSxLQUFLLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFBRyxTQUM5RixHQUFFO0FBQUUsV0FBTztBQUFBLEVBQU07QUFDekI7QUFFQSxJQUFPLG9CQUFRLE9BQU8sUUFBUTtBQUM1QixRQUFNLE1BQU0sSUFBSSxJQUFJLElBQUksR0FBRztBQUMzQixRQUFNLE9BQU8sTUFBTSxJQUFJLFNBQVMsUUFBUSx1Q0FBc0MsRUFBRSxDQUFDO0FBR2pGLE1BQUcsSUFBSSxXQUFTLFVBQVUsU0FBTyxzQkFBc0IsU0FBTyxXQUFVO0FBQ3RFLFdBQU8sS0FBSyxLQUFJLEVBQUMsSUFBRyxLQUFJLENBQUM7QUFBQSxFQUMzQjtBQUVBLE1BQUcsSUFBSSxXQUFTLFdBQVcsU0FBTyxxQkFBcUIsU0FBTyxVQUFTO0FBQ3JFLFVBQU0sT0FBTyxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sTUFBSSxJQUFJO0FBQzVDLFFBQUcsQ0FBQztBQUFNLGFBQU8sS0FBSyxLQUFJLEVBQUMsT0FBTSxXQUFVLENBQUM7QUFDNUMsVUFBTSxFQUFDLFVBQVMsU0FBUSxJQUFJO0FBQzVCLFFBQUcsYUFBVyxXQUFXLGFBQVcsU0FBUTtBQUMxQyxZQUFNLEVBQUMsT0FBTSxJQUFHLElBQUksU0FBUyxFQUFFLFVBQVMsU0FBUyxNQUFLLFFBQVEsQ0FBQztBQUMvRCxhQUFPLEtBQUssS0FBSSxFQUFDLE9BQU0sS0FBSSxNQUFLLEVBQUMsTUFBSyxTQUFRLE1BQUssUUFBTyxFQUFDLENBQUM7QUFBQSxJQUM5RDtBQUNBLFdBQU8sS0FBSyxLQUFJLEVBQUMsT0FBTSxVQUFTLENBQUM7QUFBQSxFQUNuQztBQUVBLE1BQUcsSUFBSSxXQUFTLFVBQVUsU0FBTyxrQkFBa0IsU0FBTyxPQUFNO0FBQzlELFVBQU0sS0FBSyxnQkFBZ0IsSUFBSSxRQUFRLElBQUksZUFBZSxLQUFHLEVBQUU7QUFDL0QsUUFBRyxDQUFDO0FBQUksYUFBTyxLQUFLLEtBQUksRUFBQyxPQUFNLGVBQWMsQ0FBQztBQUM5QyxXQUFPLEtBQUssS0FBSSxFQUFDLE1BQUssRUFBQyxNQUFLLEdBQUcsVUFBVSxNQUFLLEdBQUcsS0FBSSxFQUFDLENBQUM7QUFBQSxFQUN6RDtBQUVBLFNBQU8sS0FBSyxLQUFJLEVBQUMsT0FBTSxhQUFhLEtBQUksQ0FBQztBQUMzQzsiLAogICJuYW1lcyI6IFtdCn0K
