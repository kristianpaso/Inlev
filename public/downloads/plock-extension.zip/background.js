
let PLOCK_tracking=false;let PLOCK_count=0;const PLOCK_ports=new Set();
function PLOCK_broadcast(m){for(const p of [...PLOCK_ports]){try{p.postMessage(m)}catch(e){PLOCK_ports.delete(p)}}}
chrome.runtime.onConnect.addListener(port=>{if(port.name!=='plock-bridge')return;PLOCK_ports.add(port);
try{port.postMessage({type:'stats',tracking:PLOCK_tracking,plockCount:PLOCK_count})}catch(e){}
port.onDisconnect.addListener(()=>PLOCK_ports.delete(port));
port.onMessage.addListener(msg=>{if(!msg)return;if(msg.type==='startTracking'){PLOCK_tracking=true;try{chrome.storage?.local?.set?.({PLOCK_tracking:true})}catch(e){};try{port.postMessage({type:'status',status:'Plock-tracking aktiverad!'})}catch(e){};PLOCK_broadcast({type:'stats',tracking:PLOCK_tracking,plockCount:PLOCK_count})}
else if(msg.type==='getStats'){try{port.postMessage({type:'stats',tracking:PLOCK_tracking,plockCount:PLOCK_count})}catch(e){}}
else if(msg.type==='ping'){try{port.postMessage({type:'pong'})}catch(e){}}})});
chrome.runtime.onMessage.addListener((msg,s,r)=>{if(!msg)return;if(msg.type==='plock'){if(PLOCK_tracking){PLOCK_count++;try{chrome.storage?.local?.set?.({PLOCK_count:PLOCK_count})}catch(e){};PLOCK_broadcast({type:'stats',tracking:PLOCK_tracking,plockCount:PLOCK_count})}r&&r({ok:true})}});
