
let tracking = false;
let plockCount = 0;
const plockPorts = new Set();
function broadcast(msg){ for(const p of [...plockPorts]){ try{ p.postMessage(msg); }catch(e){ plockPorts.delete(p); } } }
chrome.runtime.onConnect.addListener((port)=>{
  if(port.name!=='plock-bridge') return;
  plockPorts.add(port);
  port.postMessage({type:'stats', tracking, plockCount});
  port.onDisconnect.addListener(()=> plockPorts.delete(port));
  port.onMessage.addListener((msg)=>{
    if(!msg) return;
    if(msg.type==='startTracking'){ tracking=true; chrome.storage.local.set({tracking:true}); port.postMessage({type:'status', status:'Plock-tracking aktiverad!'}); broadcast({type:'stats', tracking, plockCount}); }
    else if(msg.type==='getStats'){ port.postMessage({type:'stats', tracking, plockCount}); }
  });
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
  if(msg && msg.type==='plock'){ if(tracking){ plockCount++; chrome.storage.local.set({plockCount}); broadcast({type:'stats', tracking, plockCount}); } sendResponse && sendResponse({ok:true}); }
});
