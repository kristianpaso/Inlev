
(function(){
  let lastSig = ""; let sending=false;
  function signature(){ const a=document.querySelector('#ctl00_MonitorContentPlaceholder_PickView_flbSpeditorId_InputTemplateItem_txtSpeditorId'); const b=document.querySelector('#ctl00_MonitorContentPlaceholder_PickView_lblCurrentUser'); const c=document.getElementById('aspnetForm'); return [a?a.value:'', b?(b.innerText||b.textContent||''):'', c?(c.getAttribute('data-ver')||c.innerHTML.length):0].join('|'); }
  function maybePlock(){ const s=signature(); if(s && s!==lastSig){ lastSig=s; if(!sending){ sending=true; try{ chrome.runtime.sendMessage({type:'plock'}, ()=>{sending=false;}); }catch(e){sending=false;} } } }
  lastSig=signature(); setInterval(maybePlock,1500);
  const form=document.getElementById('aspnetForm'); if(form){ const mo=new MutationObserver(maybePlock); mo.observe(form,{childList:true,subtree:true,attributes:true,characterData:true}); }
})();
