
(function(){
  try{
    if(!location.pathname || !location.pathname.startsWith('/plock')) return;
    const port=chrome.runtime.connect({name:'plock-bridge'});
    window.addEventListener('message',(e)=>{ const msg=e&&e.data; if(!msg||!msg.type) return; if(msg.type==='PLOCK_ACTIVATE'){ port.postMessage({type:'startTracking'});} else if(msg.type==='PLOCK_GET_STATS'){ port.postMessage({type:'getStats'});} });
    port.onMessage.addListener((msg)=>{ if(!msg) return; if(msg.type==='status'){ window.postMessage({type:'PLOCK_STATUS', status: msg.status}, '*'); } else if(msg.type==='stats'){ window.postMessage({type:'PLOCK_STATS', tracking: msg.tracking, plockCount: msg.plockCount}, '*'); } });
    window.postMessage({type:'PLOCK_BRIDGE_READY'}, '*');
  }catch(e){}
})();
