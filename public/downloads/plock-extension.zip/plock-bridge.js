
(function(){if(!location.pathname.startsWith('/plock'))return;let port=null,retry=null;
function connect(){try{clearTimeout(retry);port=chrome.runtime.connect({name:'plock-bridge'});
port.onDisconnect.addListener(()=>{port=null;retry=setTimeout(connect,1000)});
port.onMessage.addListener(msg=>{if(!msg)return;if(msg.type==='status')window.postMessage({type:'PLOCK_STATUS',status:msg.status},'*');else if(msg.type==='stats')window.postMessage({type:'PLOCK_STATS',tracking:msg.tracking,plockCount:msg.plockCount},'*')});
window.postMessage({type:'PLOCK_BRIDGE_READY'},'*')}catch(e){retry=setTimeout(connect,1000)}}
function safe(o){try{if(!port){connect();return}port.postMessage(o)}catch(e){port=null;retry=setTimeout(connect,1000)}}
window.addEventListener('message',e=>{const m=e&&e.data;if(!m||!m.type)return;if(m.type==='PLOCK_ACTIVATE')safe({type:'startTracking'});else if(m.type==='PLOCK_GET_STATS')safe({type:'getStats'})});
setInterval(()=>safe({type:'ping'}),15000);connect()})();
