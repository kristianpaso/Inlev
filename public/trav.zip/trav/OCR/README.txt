OCR-fix: ingen logger skickas till worker, säkra åtkomster till data.words/data.text.
