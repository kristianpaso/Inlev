
Trav uppdatering 2025-10-18T21:30:25
- Lagt in Trav UI v5.4 (badge + proof) och v5.3 (layout).
- app.js uppdaterad genom att blocken ligger sist i filen.
- index.html kontrollerad för script include (./trav/app.js?v=DEV).

Om du inte ser 'Trav UI v5.4 active' efter omladdning: töm cache (Ctrl+F5) och kolla konsolen.
