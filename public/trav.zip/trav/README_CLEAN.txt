CLEAN DROP-IN (Trav UI v5.6.2)
1) Ersätt din `public/trav/app.js` med denna.
2) Ta bort ALLA `app.additions.*.js` och alla <script src="...additions..."> i HTML.
3) Överblicken: <body data-page="overview"> (ingen #gameId här).
4) Spelsystem: <input type="hidden" id="gameId" value="V64-YYYY-MM-DD-XXXX"> (endast här).
