// app.js — Trav UI v5.6.2 + Create-Game hook (v5.6.3)
/* ==== Trav UI v5.6.2 — ULTRA-STRICT + EARLY NUKE ==== */
(function(){
  try { var kill = id => { var n=document.getElementById(id); if(n&&n.parentNode) n.parentNode.removeChild(n); };
    ["trv53","trv54-proof","trv54","trv55"].forEach(kill);
  } catch(e) {}

  const STYLE = `
:root{--bg:#0b1220;--card:#111827;--line:#1f2937;--text:#e5e7eb;--muted:#9ca3af;--brand:#38bdf8;--danger:#ef4444;--ink:#0b0e14;--summary:#22252b}
.trv56{font-family:system-ui,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:var(--text)}
.trv56-wrap{margin:14px 0}
.trv56-grid{display:grid;gap:12px}
.trv56-grid.q{grid-template-columns:repeat(4,minmax(0,1fr))}
@media (max-width:1200px){.trv56-grid.q{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:900px){.trv56-grid.q{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:640px){.trv56-grid.q{grid-template-columns:repeat(1,minmax(0,1fr))}}
.trv56-card{background:var(--card);border:2px solid var(--line);border-radius:12px;padding:10px}
.trv56-mini{font-size:.9rem;color:var(--muted)}
.trv56-strong{font-weight:700}
.trv56-dcard{background:var(--ink);border:2px solid var(--text);border-radius:10px;padding:10px}
.trv56-h{font-weight:800;font-size:1.35rem;text-align:center;margin:6px 0 8px}
.trv56-row{display:grid;grid-template-columns:1fr 2fr 1fr;gap:12px;align-items:center;margin:8px 0}
.trv56-num{width:36px;height:36px;border:3px solid var(--text);border-radius:6px;display:flex;align-items:center;justify-content:center;font-weight:800}
.trv56-num.pop{border-color:#ddd;background:#0b1524}
.trv56-num.pop.on{background:var(--danger);border-color:var(--danger);color:white}
.trv56-num.mine{cursor:pointer;border-color:#ddd}
.trv56-num.mine.on{background:var(--brand);border-color:var(--brand);color:#001926}
.trv56-sticky{position:sticky;bottom:0;background:var(--summary);border-top:2px solid var(--line);padding:10px;border-radius:12px 12px 0 0;margin-top:12px}
.trv56-sum{display:grid;grid-template-columns:repeat(6,1fr);gap:6px}
.trv56-pill{display:inline-block;margin:0 4px 4px 0;padding:.15rem .45rem;border-radius:999px;background:#1f2937}
`;
  function css(){ if(document.getElementById('trv562-css')) return; const s=document.createElement('style'); s.id='trv562-css'; s.textContent=STYLE; document.head.appendChild(s); }

  const $ = (sel,root=document)=>root.querySelector(sel);
  const $$ = (sel,root=document)=>Array.from(root.querySelectorAll(sel));

  function nukeLegacyLater(){
    ['#trv53','#trv54','#trv54-proof','#trv55','.trv54-proof','.trv54-banner','.trv53','.trv55'].forEach(sel=> $$(sel).forEach(n=>n.remove()));
    $$('div,section').forEach(el=>{ if(/Ny layout monterad/i.test(el.textContent||'')) el.remove(); });
  }

  function hasGameId(){ return !!$('#gameId'); }
  function isOverview(){
    if(document.body?.dataset?.page === 'overview') return true;
    const h1 = $('h1'); return !!(h1 && /Överblick/i.test(h1.textContent||''));
  }
  function isGameView(){ return hasGameId() && !isOverview(); }

  const KEY='games'; const AVDS=6, MAX=12;
  function read(){ try{ return JSON.parse(localStorage.getItem(KEY)||'{}'); }catch(_){ return {}; } }
  function write(db){ try{ localStorage.setItem(KEY, JSON.stringify(db)); }catch(_){} }
  function gid(){ return $('#gameId')?.value || null; }
  function getGame(id=gid()){ const db=read(); if(!id) return { id:null, coupons:[] }; return db[id] || { id, coupons:[] }; }
  function setGame(updater, id=gid()){
    if(!id) return; const db=read(); const prev = db[id] || { id, coupons:[] };
    const next = (typeof updater==='function') ? updater(prev) : updater; db[id]=next; write(db); return next;
  }
  function migrateLegacyCoupons(id){
    const g=getGame(id); let changed=false;
    const migrated=(g.coupons||[]).map(c=> c && !c.gameId ? (changed=true, {...c, gameId:id}) : c);
    if(changed) setGame(prev=>({...prev, coupons:migrated}), id);
  }

  window.TravUI = window.TravUI || {};
  window.TravUI.newGame = function(prefix){
    const input = $('#gameId'); // får vara null på överblick
    const p = prefix || ($('#formType')?.value) || 'V64';
    const id = `${p}-${new Date().toISOString().slice(0,10)}-${Math.floor(Math.random()*100000)}`;
    if (input) input.value = id;
    setGame(prev=>prev, id);
    return id;
  };
  window.TravUI.assignGame = function(id){
    let input = $('#gameId');
    if(!input){ input=document.createElement('input'); input.type='hidden'; input.id='gameId'; document.body.appendChild(input); }
    input.value=id;
    boot(true);
    return id;
  };

  function removeOverlay(){ $('#trv56')?.remove(); }
  function overlay(){
    if(!isGameView()) return null;
    let host=$('#trv56'); if(host) return host;
    host=document.createElement('section'); host.id='trv56'; host.className='trv56';
    host.innerHTML=`
      <div class="trv56-wrap"><div class="trv56-grid q" id="trv56-coupons"></div></div>
      <div class="trv56-wrap">
        <div class="trv56-dcard" id="trv56-board">
          <div class="trv56-h">Avdelning 1–6</div>
          <div id="trv56-divs"></div>
          <div class="trv56-sticky">
            <div class="trv56-sum" id="trv56-sum"></div>
            <div style="text-align:right;margin-top:6px"><span id="trv56-price" class="trv56-mini trv56-strong">Pris: 0 kr</span></div>
          </div>
        </div>
      </div>`;
    (document.querySelector('main')||document.body).appendChild(host);
    return host;
  }

  function renderCoupons(){
    const id=gid(); if(!id) return;
    const grid=overlay()?.querySelector('#trv56-coupons'); if(!grid) return;
    const list=(getGame(id).coupons||[]).filter(c=>c && c.gameId===id);
    grid.innerHTML = list.map(c=>{
      const title=(c.name||'Kupong');
      const rows=(c.rows||[]).sort((a,b)=>a.avd-b.avd).map(r=>`<div>${r.avd}: ${r.horses.join(' ')}</div>`).join('');
      return `<div class="trv56-card"><div class="trv56-strong">Avd | Hästar</div><div class="trv56-mini trv56-strong" style="margin:4px 0">${title}</div><div class="trv56-mini">${rows||'<i>Tom</i>'}</div></div>`;
    }).join('') || '<div class="trv56-mini">Inga kuponger ännu för detta spelsystem.</div>';
  }

  function popular(id){
    const cps=(getGame(id).coupons||[]).filter(c=>c && c.gameId===id && Array.isArray(c.rows) && c.rows.length);
    const agg=Array(AVDS).fill(0).map(()=>new Map());
    cps.forEach(c=>c.rows.forEach(r=>r.horses.forEach(h=>{const m=agg[r.avd-1]; m.set(h,(m.get(h)||0)+1)})));
    const thr=Math.ceil(Math.max(1,cps.length)*0.5);
    return Array(AVDS).fill(0).map((_,i)=>{
      const pairs=[...agg[i].entries()].sort((a,b)=>b[1]-a[1]||a[0]-b[0]);
      let picks=pairs.filter(([h,c])=>c>=thr).map(([h])=>h);
      if(!picks.length) picks=pairs.slice(0,3).map(([h])=>h);
      return picks.sort((a,b)=>a-b);
    });
  }

  function renderDivs(){
    const id=gid(); if(!id) { removeOverlay(); return; }
    const box=overlay()?.querySelector('#trv56-divs'); if(!box) return;
    box.innerHTML='';
    const pop=popular(id);
    for(let a=1;a<=AVDS;a++){
      let rows='';
      for(let h=1;h<=MAX;h++){
        rows += `<div class="trv56-row">
          <div><div class="trv56-num pop" data-a="${a}" data-h="${h}">${h}</div></div>
          <div><div class="trv56-mini trv56-strong">Hästnamn ${h}</div><div class="trv56-mini">Kusk</div></div>
          <div style="text-align:right"><div class="trv56-num mine" data-a="${a}" data-h="${h}">${h}</div></div>
        </div>`;
      }
      const card=document.createElement('div'); card.className='trv56-card'; card.style.margin='10px 0';
      card.innerHTML = `<div class="trv56-strong trv56-mini" style="text-align:center;margin-bottom:6px">Avdelning ${a}</div>${rows}`;
      box.appendChild(card);
    }
    pop.forEach((list,i)=> list.forEach(h=>{
      const el=box.querySelector(`.trv56-num.pop[data-a="${i+1}"][data-h="${h}"]`); if(el) el.classList.add('on');
    }));
    box.addEventListener('click', (e)=>{
      const t=e.target.closest('.trv56-num.mine'); if(!t) return; t.classList.toggle('on'); sum();
    });
  }

  function sum(){
    const grid=$('#trv56-sum'); if(!grid) return; grid.innerHTML='';
    let price=1;
    for(let a=1;a<=AVDS;a++){
      const picked=$$(`.trv56-num.mine.on[data-a="${a}"]`).map(el=>+el.dataset.h).sort((x,y)=>x-y);
      const col=document.createElement('div'); col.innerHTML = `<div class="trv56-mini">Avd ${a}:</div><div>${picked.map(n=>`<span class="trv56-pill">${n}</span>`).join('')||'<span class="trv56-mini">—</span>'}</div>`;
      grid.appendChild(col); price *= Math.max(1,picked.length);
    }
    const p=$('#trv56-price'); if(p) p.textContent=`Pris: ${price} kr`;
  }

  document.addEventListener('coupon-changed', (e)=>{
    if(!isGameView()) return; const id=gid();
    const d=e.detail||{}; if(!Array.isArray(d.rows) || !d.rows.length) return;
    setGame(prev=>({ ...prev, coupons:[...(prev.coupons||[]), { name: d.name||'Kupong', rows: d.rows, gameId: id }] }), id);
    renderCoupons();
  });

  function boot(force){
    css(); nukeLegacyLater();
    if(!isGameView()){ removeOverlay(); return; }
    if(force) removeOverlay();
    migrateLegacyCoupons(gid());
    overlay(); renderCoupons(); renderDivs(); sum();
    const g=$('#gameId'); if(g && !g.__wired){ g.__wired=true; g.addEventListener('change', ()=>boot(true)); }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', ()=>boot()); else boot();
})();
/* ==== /Trav UI v5.6.2 ==== */

// --- KOPPLA "Skapa spelsystem" + läs gameId från URL --- //
(function () {
  function getParam(name) { return new URLSearchParams(window.location.search).get(name); }

  document.addEventListener('DOMContentLoaded', () => {
    const isOverview = document.body?.dataset?.page === 'overview';

    if (isOverview) {
      const btn = document.querySelector('[data-action="create-game"]') || document.getElementById('createGameBtn');
      if (btn && !btn.__wired) {
        btn.__wired = true;
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          const id = (window.TravUI?.newGame && window.TravUI.newGame('V64')) || `GAME-${Date.now()}`;
          window.location.href = `trav.html?game=${encodeURIComponent(id)}`;
        });
      }
    } else {
      const gid = getParam('game');
      if (gid) {
        let hidden = document.getElementById('gameId');
        if (!hidden) {
          hidden = document.createElement('input');
          hidden.type = 'hidden'; hidden.id = 'gameId';
          document.body.appendChild(hidden);
        }
        hidden.value = gid;
        if (window.TravUI?.assignGame) window.TravUI.assignGame(gid);
      }
    }
  });
})();